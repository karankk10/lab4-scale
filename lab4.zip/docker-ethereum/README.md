MIT License
# docker-ethereum
Ethereum DAPP will run inside the docker container.

Follow the below link for the explanation  
https://medium.com/@shubhamchadokar04/create-an-ethereum-dapp-with-react-and-docker-211223005f17
